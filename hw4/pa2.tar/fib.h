#ifndef _FIB_H_
#define _FIB_H_

extern int fib(int n);

#endif
